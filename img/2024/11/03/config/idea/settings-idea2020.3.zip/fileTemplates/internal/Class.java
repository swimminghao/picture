#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
 * 
 * @Author: XueHao
 * @Date: ${YEAR}/${MONTH}/${DAY}
 * @Description: 
 */
public class ${NAME} {
}
