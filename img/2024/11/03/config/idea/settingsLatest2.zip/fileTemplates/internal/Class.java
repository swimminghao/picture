#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
 * 
 * @Author: XueHao
 * @Date: ${YEAR}/${MONTH}/${DAY}
 * @Copyright: Copyright (c) wayyue.com Corporation. All Rights Reserved.
 */
public class ${NAME} {
}
